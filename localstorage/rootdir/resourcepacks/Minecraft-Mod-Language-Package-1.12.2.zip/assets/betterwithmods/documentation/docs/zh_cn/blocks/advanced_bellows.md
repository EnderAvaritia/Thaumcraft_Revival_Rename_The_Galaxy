![弹簧动力风箱](block:betterwithmods:bellows@1)

 弹簧动力风箱是普通风箱的升级版，能够在持续充能的情况下自动完成吸气和喷气的过程，需要[融魂钢弹簧](../items/soulforged_steel.md).